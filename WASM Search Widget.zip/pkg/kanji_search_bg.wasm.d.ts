/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function search_kanji_by_stroke_count(a: number, b: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
