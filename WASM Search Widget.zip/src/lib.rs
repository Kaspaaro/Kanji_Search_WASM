mod utils;
use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
#[allow(non_snake_case)]
struct KanjiEntry {
    Kanji: String,
    Strokes: u8,
    #[serde(rename = "Reading within Joyo")]
    Reading_within_Joyo: String,
    #[serde(rename = "On within Joyo")]
    On_within_Joyo: String,
    #[serde(rename = "Kun within Joyo")]
    Kun_within_Joyo: String,
    #[serde(rename = "Translation of Kun")]
    Translation_of_Kun: String,
}

#[wasm_bindgen]
extern "C" {
    fn alert(s: &str);
}
#[wasm_bindgen]
pub fn search_kanji_by_stroke_count(stroke_count: u8) -> Result<JsValue, JsValue> {
    let data_str = include_str!("www/kanjiJSON.json");
    let kanji_entries: Result<Vec<KanjiEntry>, _> = serde_json::from_str(data_str);

    let kanji_entries = match kanji_entries {
        Ok(entries) => entries,
        Err(err) => {
            return Err(JsValue::from_str(&format!("Error parsing JSON: {:?}", err)));
        }
    };

    let matching_kanji: Vec<&KanjiEntry> = kanji_entries
        .iter()
        .filter(|entry| entry.Strokes == stroke_count)
        .collect();

    let result: Vec<String> = matching_kanji
        .iter()
        .map(|entry| {
            format!(
                r#"
                <div id="KanjiResult">
                    <p>Kanji: {} </p>
                    <p>Reading within Joyo: {} </p>
                    <p>On within Joyo: {} </p>
                    <p>Kun within Joyo: {} </p>
                    <p>Translation of Kun: {} </p>
                </div>
            "#,
                entry.Kanji,
                entry.Reading_within_Joyo,
                entry.On_within_Joyo,
                entry.Kun_within_Joyo,
                entry.Translation_of_Kun
            )
        })
        .collect();

    Ok(JsValue::from_str(&format!(
        "
        <div id='KanjiResultAll'>
            <h3>Results for Stroke Count: {}</h3>
            {}
        </div>
    ",
        stroke_count,
        result.join("\n"),
    )))
}

//When generating a PKG comment the tests and then generate the PKG, after its done uncomment the tests and the tests work.

#[cfg(test)]
wasm_bindgen_test::wasm_bindgen_test_configure!(run_in_browser);
mod test {
    use wasm_bindgen::{JsCast, JsValue};
    use wasm_bindgen_test::*;
    use crate::search_kanji_by_stroke_count;

    #[wasm_bindgen_test]
    fn test_search_kanji_by_stroke_count() {
        // Test with existing stroke count
        let stroke_count_1 = 5;
        let result_1 = search_kanji_by_stroke_count(stroke_count_1);
        assert!(result_1.is_ok(), "Function call failed");

        // Test with non-existing stroke count
        let stroke_count_2 = 10;
        let result_2 = search_kanji_by_stroke_count(stroke_count_2);
        assert!(result_2.is_ok(), "Function call failed");

        // Verify results
        let result_html_1 = result_1.unwrap().as_string().unwrap();
        assert!(result_html_1.contains("Results for Stroke Count: 5"), "Unexpected result");

        let result_html_2 = result_2.unwrap().as_string().unwrap();
        assert!(result_html_2.contains("Results for Stroke Count: 10"), "Unexpected result");
    }

    #[wasm_bindgen_test]
    fn test_search_kanji_with_0_strokes() {
        let result = search_kanji_by_stroke_count(0);
        assert!(result.is_err(), "Should return an error");
    }

    #[wasm_bindgen_test]
    fn test_kanji_funcs() {
        let result = search_kanji_by_stroke_count(7);
        assert!(result.is_ok());
        let result = result.unwrap();
        let result_html: JsValue = result.unchecked_into();

        // Ensure the result contains the stroke count header
        let result_html_str = result_html.as_string().unwrap();
        assert!(result_html_str.contains("Results for Stroke Count: 7"));

        // Ensure the result contains the expected kanji entry
        assert!(result_html_str.contains("Kanji: 亜"));
        assert!(result_html_str.contains("Reading within Joyo: ア"));
        assert!(result_html_str.contains("On within Joyo: a"));
        assert!(result_html_str.contains("Kun within Joyo: -"));
        assert!(result_html_str.contains("Translation of Kun: -"));
    }

}
